# Veri Çekme ve Veri Seti Oluşturma Betikleri (`scripts/`)

Bu klasör, `docs/model_oncesi/degiskenler.json` ve `docs/model_oncesi/DEGISKEN_LISTESI.md` belgelerini referans alarak **2010–2020 (44 çeyrek)** dönemi için **6 farklı sektörden 5'er şirketin (toplam 30 BIST şirketi)** KAP finansal raporlarını, Türkiye makroekonomik göstergelerini ve küresel risk endekslerini çeken ve birleştiren Python betiklerini içerir.

**7 Kasım 2026 denetimi:** Mevcut çıktı ham gözlem tablosudur; doğrudan eğitim girdisi ve yayın zamanı güvenli veri seti olarak doğrulanmadı. Finansal tutar/birim, rapor sürümü, iki CSV'nin metadata farkları ve makro yayın gecikmelerine ilişkin bulgular [veri denetimindedir](../docs/model_oncesi/VERI_DENETIMI_2026-11-07.md).

## Betikler ve Görevleri

1. **[`fetch_external_macro_and_risk.py`](fetch_external_macro_and_risk.py)**
   - KAP finansal raporlarında yer almayan dışsal değişkenleri (`degiskenler.json` içerisinde belirtilen resmi kaynaklardan) indirir ve `data/external/` altına kaydeder:
     - **Küresel Risk (`R01`–`R04`)**: Caldara & Iacoviello Jeopolitik Risk Endeksi (`GPR`, `GPRT`, `GPRA` — `matteoiacoviello.com`), Küresel Ekonomik Politika Belirsizliği (`GEPU_ppp` — `policyuncertainty.com`) ve OFR Finansal Stres Endeksi (`OFR FSI` — `financialresearch.gov`).
     - **Türkiye Makroekonomik Göstergeleri (`M01`–`M06`)**: Günlük `USD/TRY` ve `EUR/TRY` kurları (`Yahoo Finance / TCMB`), Türkiye politika/bankalararası faiz oranı (`TCMB / OECD MEI`), `TÜFE` ve `Yİ-ÜFE` yıllık enflasyon oranları (`TCMB / TÜİK`) ve Takvim Etkisinden Arındırılmış Sanayi Üretim Endeksi yıllık değişimi (`TÜİK / OECD MEI`).

2. **[`fetch_kap_financials_2010_2020.py`](fetch_kap_financials_2010_2020.py)**
   - KAP'ın dönemlik toplu finansal tablo arşivlerinden (`/tr/api/financialTable/download/{year}/{period}`) 2010 Q1 – 2020 Q4 arasındaki 44 çeyreğin arşivlerini (`data/kap_zips/`) indirir.
   - Seçilen 6 sektördeki 30 şirketin `.xls` formatındaki finansal raporlarını `data/kap_raw_xls/` klasörüne çıkarır.
   - KAP bildirim sorgu API'si (`/tr/api/disclosure/members/byCriteria`) üzerinden yalnızca **Finansal Rapor (`FR`)** bildirimlerini sorgulayarak yayın zamanlarını ve bildirim numaralarını `data/kap_fr_catalog_2010_2020.json` dosyasına kaydeder. Nihai tablodaki `first_published_at` alanının gerçekten ilk sürüme ait olduğu ayrıca doğrulanmalıdır.

3. **[`parse_and_build_dataset.py`](parse_and_build_dataset.py)**
   - `data/kap_raw_xls/` altındaki hem **2010–2015 BIFF8 Excel (`.xls`)** hem de **2016–2020 HTML tabanlı (`.xls`)** KAP finansal tablolarını ayrıştırır.
   - Ham başlıktaki raporlama birimine (`TL`, `1.000 TL`, `Bin TL`) göre parasal tutarları **TL (`TRY`)** cinsine dönüştürür. Kaynak başlığının hatalı olduğu ölçek şüphelileri denetimde ayrıca işaretlendi.
   - Gelir Tablosu ve Nakit Akış Tablosu kalemleri için hem kümülatif (`_ytd`) hem de tek çeyreklik (`_ceyrek`) akış değerlerini üretir.
   - 17 çekirdek finansal kalemi (`T01`–`T17`), finansal oran ve büyüme serilerini, Türkiye makro serilerini (`M01`–`M06`), küresel risk serilerini (`R01`–`R04`) ve etkileşim terimlerini (`X02`, `X03`) dönem sonuna eşler. Bu eşleme yayın zamanını/sürümünü garanti etmez; eğitim için geçmiş girdiler ve gelecek hedefler ayrıca hazırlanmalıdır. F kodları sözlükle birebir örtüşmediğinden açık kolon eşlemesi gereklidir.
   - Çıktıyı [`kök CSV`](../bist_bilanco_tahmini_2010_2020.csv) ve [`data/ CSV`](../data/bist_bilanco_tahmini_2010_2020.csv) olarak kaydetmeye çalışır. İkinci dosyaya yazılamazsa kopyalar farklı kalabilir; mevcut kopyalar aynı sürüm değildir.

4. **[`audit_dataset.py`](audit_dataset.py)**
   - Standart Python kütüphanesiyle iki mevcut CSV'yi okur; panel/doluluk, tutarlılık, sonlu sayı, dönem/yayın zamanı, kopya farkları ve günlük pencere kontrollerini yapar.
   - Veri indirmez, CSV/XLS değiştirmez ve model eğitmez. İstenirse sayısal bulguları ayrı JSON'a yazar; şüphe bayrakları otomatik düzeltme veya hata kanıtı değildir.

```bash
python3 scripts/audit_dataset.py
python3 scripts/audit_dataset.py --output /tmp/bilanco-veri-denetimi.json
```

## Çalıştırma Sırası

```bash
python scripts/fetch_external_macro_and_risk.py
python scripts/fetch_kap_financials_2010_2020.py
python scripts/parse_and_build_dataset.py
```
